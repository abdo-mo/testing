"use strict";
new WOW().init();
//Start NAV
$("nav .navbar-toggler").click(function(){
    let that = this;
    if($(this).attr('aria-expanded')=="false"){
        $(this).children(".top,.span").css('top','50%');
        $(this).children(".bottom").css('opacity','0');
        $(this).children(".span").css('margin',' 0');
        setTimeout(function(){
            $(that).children("span").css('transform','rotateZ(45deg)');
            $(that).children(".span").css('transform','rotateZ(-45deg)');
        });
    }else{
        $(this).children(".top,.span").css('top','50%');
        $(this).children(".bottom").css('opacity','1');
        $(this).children(".span").css('margin','3px  0');
        setTimeout(function(){
            $(that).children("span").css('transform','rotateZ(0deg)');
            $(that).children(".span").css('transform','rotateZ(0deg)');
        });
    }
    });
//end header a navbar 
// Start data-link
$("nav .nav-item").click(function(){
    $(this).addClass("active").siblings().removeClass("active");
    let newNavbar=$(`#${$(this).children('.nav-link').attr('data-section')}`).position().top;
    let newNav =$('nav').innerHeight();
    $("html").animate({"scrollTop":newNavbar-newNav},100);
    });
    // End data-link
    $(".jquery").click(function(){
        alert('Very soon in a new version');
        prompt("Very soon in a new version")
    })
    $(document).ready(function () {
        $(".logos").fadeOut(3000);
      });
    // $(".nav-item").click(function(){
    //     $(this).addClass("active").siblings().removeClass("active");
    //     let newNavbar=$(`#${$(this).children('.nav-link').attr('data-section')}`).position().top;
    //     let newNav =$('nav').innerHeight();
    //     $("html").animate({"scrollTop":newNavbar-newNav},100);
    //     });